<!DOCTYPE html>
<!--
	Daraz by TEMPLATE STOCK
	templatestock.co @templatestock
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->

<html lang="en">
	<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MEETME MEX</title>
    <link rel="icon"  href="../resources/images/meetme logo.jpeg" />

    <link rel="stylesheet" href="../resources/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="../resources/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="../resources/css/animate.css"/>

		<link rel="stylesheet" href="../resources/css/style.css" />

    <script type="text/javascript" src="../resources/js/jquery-1.11.2.min.js"></script>
    <script type="text/javascript" src="../resources/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCZXJBVDf7R4JqmSpopVPoduIGWx1IwpBM"></script>
    <script type="text/javascript" src="../resources/js/plugins.js"></script>

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

	</head>
	<body>
	<div class="svg-wrap">
      <svg width="64" height="64" viewBox="0 0 64 64">
        <path id="arrow-left" d="M26.667 10.667q1.104 0 1.885 0.781t0.781 1.885q0 1.125-0.792 1.896l-14.104 14.104h41.563q1.104 0 1.885 0.781t0.781 1.885-0.781 1.885-1.885 0.781h-41.563l14.104 14.104q0.792 0.771 0.792 1.896 0 1.104-0.781 1.885t-1.885 0.781q-1.125 0-1.896-0.771l-18.667-18.667q-0.771-0.813-0.771-1.896t0.771-1.896l18.667-18.667q0.792-0.771 1.896-0.771z"></path>
      </svg>

      <svg width="64" height="64" viewBox="0 0 64 64">
        <path id="arrow-right" d="M37.333 10.667q1.125 0 1.896 0.771l18.667 18.667q0.771 0.771 0.771 1.896t-0.771 1.896l-18.667 18.667q-0.771 0.771-1.896 0.771-1.146 0-1.906-0.76t-0.76-1.906q0-1.125 0.771-1.896l14.125-14.104h-41.563q-1.104 0-1.885-0.781t-0.781-1.885 0.781-1.885 1.885-0.781h41.563l-14.125-14.104q-0.771-0.771-0.771-1.896 0-1.146 0.76-1.906t1.906-0.76z"></path>
      </svg>
    </div>


    <!-- MAIN CONTENT -->

   <div class="container-fluid">

    <!-- HEADER -->

    <section id="header">

      <!-- NAVIGATION -->
      <nav class="navbar navbar-fixed-top navbar-default bottom">
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#menu">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#header">MEETME</a>
          </div><!-- /.navbar-header -->

          <div class="collapse navbar-collapse" id="menu">
            <ul class="nav navbar-nav navbar-right">
              <li><a href="#header">Inicio</a></li>
              <li><a href="#acerca de nostros ">Acerca de nosotros</a></li>              
              <li><a href="#portfolio">Portfolio</a></li>
             
			  <li><a href="#team">Equipo</a></li>
			  
              <li><a href="#contact">Contacto</a></li>
            </ul>
          </div> <!-- /.navbar-collapse -->
        </div> <!-- /.container -->
      </nav>

      <!-- SLIDER -->
      <div class="header-slide">
        <section>
          <div id="loader" class="pageload-overlay" data-opening="M 0,0 0,60 80,60 80,0 z M 80,0 40,30 0,60 40,30 z">
            <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 80 60" preserveAspectRatio="none">
              <path d="M 0,0 0,60 80,60 80,0 Z M 80,0 80,60 0,60 0,0 Z"/>
            </svg>
          </div> <!-- /.pageload-overlay -->
          
          <div class="image-slide bg-fixed">
            <div class="overlay">
              <div class="container">
                <div class="row">
                  <div class="col-md-12">

                    <div class="slider-content">
                      <h1></h1>
                      <p></p>
                    </div>

                  </div> <!-- /.col-md-12 -->
                </div> <!-- /.row -->
              </div> <!-- /.container -->
            </div> <!-- /.overlay -->
          </div> <!-- /.image-slide -->

          <nav class="nav-slide">
            <a class="prev" href="#prev">
              <span class="icon-wrap">
                <svg class="icon" width="32" height="32" viewBox="0 0 64 64">
                  <use xlink:href="#arrow-left">
                </svg>
              </span>
              <div>
                <span>Prev Photo</span>
                <h3>...</h3>
                <p>...</p>
                <img alt="Previous thumb">
              </div>
            </a>
            <a class="next" href="#next">
              <span class="icon-wrap">
                <svg class="icon" width="32" height="32" viewBox="0 0 64 64">
                  <use xlink:href="#arrow-right">
                </svg>
              </span>
              <div>
                <span>Next Photo</span>
                <h3>...</h3>
                <p>...</p>
                <img alt="Next thumb">
              </div>
            </a>
          </nav>
        </section>

        <script type="text/javascript">
        var dataHeader = [
                            {
                              bigImage :"../resources/images/meetme logo.jpeg",
                              title : "MEETME",
							  author : "Empresa mexicana que se encarga de ayudar a pqueños negocios"
                            },
                            {
                              bigImage :"../resources/images/meetme encabezado.jpeg",
                              title : "Especialistas en negocios pequeños",
                              author : "Templatestock"
                            },
                            {
                              bigImage :"../resources/images/negocio 1.jpeg",
                              title : "",
                              author : "Templatestock"
                            }
                        ],
            loaderSVG = new SVGLoader(document.getElementById('loader'), {speedIn : 600, speedOut : 600, easingIn : mina.easeinout});
            loaderSVG.show()
        </script>

      </div><!-- /.header-slide -->
    </section>

    <!-- HEADER END -->


    <!-- ABOUT -->

    <section id="acerca de nostros" class="light">
      <header class="title">
        <h2>Acerca  <span>de nosotros</span></h2>
        <p>Se nos solicito realizar una idea innovadora, funcional y que aporte algo a la sociedad, la cual respondiera a una necesidad, para esto nosotros seleccionamos el aspecto económico. En la situación que se vive hoy día, y debido a la época pandémica del “covid 19”, es más evidente la caída económica que se esta viviendo, se busca apoyar y mejorar este aspecto que ha venido afectándonos desde prácticamente inicios de la pandemia, se busca impulsar la economía, que resulte ser de fácil acceso, entendimiento, y utilización para todo tipo de personas. <strong></strong> </p>
      </header>

      
	
	    <!-- PORTFOLIO -->

    <section id="portfolio" class="light">
      <header class="title">
        <h2>Portfolio</h2>
        <p>Nuestro proyecto ayudara a la reactivación económica a sectores pequeños desde vendedores ambulantes, pequeños talleres o fábricas y pequeños locatarios y comerciantes.</p>
      </header>

      <div class="container-fluid">
        <div class="row">
          <ul id="filters" class="list-inline">
            <li data-filter="all" class="filter">All</li>
            <li data-filter=".branding" class="filter">Branding</li> 
            <li data-filter=".graphic" class="filter">Graphic</li> 
            <li data-filter=".printing" class="filter">Printing</li> 
            <li data-filter=".video" class="filter">Video</li> 
          </ul>
        </div>

        <div class="row">
          <div class="container-portfolio">
            <!-- PORTFOLIO OBJECT -->
            <script type="text/javascript">
            var portfolio = [
                    {
                      category : "branding",
                      image : "../resources/images/negocio 1.jpeg",
                      title : " <span></span>",
                      link : "#none",
                      text : ""
                    },
                    {
                      category : "graphic",
                      image : "../resources/images/negocio 2.jpeg",
                      title : " <span></span>",
                      link : "#none",
                      text : "."
                    },
                    {
                      category : "graphic",
                      image : "../resources/images/negocio 3.jpg",
                      title : "<span></span>",
                      link : "#none",
                      text : ""
                    },
                    {
                      category : "video",
                      image : "../resources/images/negocio 4.jpg",
                      title : " <span></span>",
                      link : "#none",
                      text : ""
                    },
                    {
                      category : "branding",
                      image : "../resources/images/negocio 5.jpeg",
                      title : " <span></span>",
                      link : "#none",
                      text : ""
                    },
                    {
                      category : "printing",
                      image : "../resources/images/negocio 6.jpg",
                      title : " <span></span>",
                      link : "#none",
                      text : ""
                    },
                    {
                      category : "printing",
                      image : "../resources/images/negocio 7.jpg",
                      title : " <span></span>",
                      link : "#none",
                      text : ""
                    },
                    {
                      category : "printing",
                      image : "../resources/images/negocio 8.jpg",
                      title : " <span></span>",
                      link : "#none",
                      text : ""
                    }
                ];
            </script>
          </div>
        </div>
      </div>
    </section>


    <!-- TEAM -->

    <section id="team" class="light">
      <header class="title">
        <h2>Equipo <span></span></h2>
        <p>Somos un equipo de trabajo unido y puesto para cada una de las pequeñas empresas que se nos vayan 
        poniendo en el camino.</p>
      </header>
      
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6 text-center">
            <div class="wrap animated" data-animate="fadeInDown">
              <div class="img-team">
                <img src="../resources/images/per 1.jpg" alt="" class="img-circle">
              </div>

              <h3>Eduardo Ramirez</h3>
              <h5>Creative Director</h5>

              <p>Radicando en la ciudad de leon, como trabajadores matutinos en pequeñas empresas de la ciudad.
              somos estudiantes de la Universidas Tecnologica de Leon, en la carrera de Negocios digitales, del turno vespertino.</p>

              <div class="team-social">
                <ul class="list-inline social-list">
                  <li><a href="#" class="fa fa-twitter"></a></li>
                  <li><a href="#" class="fa fa-linkedin"></a></li>
                  <li><a href="#" class="fa fa-facebook"></a></li>
                  <li><a href="#" class="fa fa-google-plus"></a></li>
                </ul> 
              </div>                
            </div>
          </div>

          <div class="col-md-3 col-sm-6 text-center">
            <div class="wrap animated" data-animate="fadeInDown"> 
              <div class="img-team">
                <img src="../resources/images/per 2.jpg" alt="" class="img-circle">
              </div>

              <h3>Diana mercedes</h3>
              <h5>Designer</h5>

              <p>Radicando en la ciudad de leon, como trabajadores matutinos en pequeñas empresas de la ciudad.
              somos estudiantes de la Universidas Tecnologica de Leon, en la carrera de Negocios digitales, del turno vespertino.</p>

              <div class="team-social">
                <ul class="list-inline social-list">
                  <li><a href="#" class="fa fa-twitter"></a></li>
                  <li><a href="#" class="fa fa-linkedin"></a></li>
                  <li><a href="#" class="fa fa-facebook"></a></li>
                  <li><a href="#" class="fa fa-google-plus"></a></li>
                </ul> 
              </div>                
            </div>
          </div>

          <div class="col-md-3 col-sm-6 text-center">
            <div class="wrap animated" data-animate="fadeInDown"> 
              <div class="img-team">
                <img src="../resources/images/per 3.webp" alt="" class="img-circle">
              </div>

              <h3>Iojana Carpio</h3>
              <h5>Developer</h5>

              <p>Radicando en la ciudad de leon, como trabajadores matutinos en pequeñas empresas de la ciudad.
              somos estudiantes de la Universidas Tecnologica de Leon, en la carrera de Negocios digitales, del turno vespertino.</p>

              <div class="team-social">
                <ul class="list-inline social-list">
                  <li><a href="#" class="fa fa-twitter"></a></li>
                  <li><a href="#" class="fa fa-linkedin"></a></li>
                  <li><a href="#" class="fa fa-facebook"></a></li>
                  <li><a href="#" class="fa fa-google-plus"></a></li>
                </ul> 
              </div>                
            </div>
          </div>

          <div class="col-md-3 col-sm-6 text-center">
            <div class="wrap animated" data-animate="fadeInDown"> 
              <div class="img-team">
                <img src="../resources/images/per 4.jpg" alt="" class="img-circle">
              </div>

              <h3>Victor Daniel "john wick"</h3>
              <h5>Commerce</h5>

              <p>Radicando en la ciudad de leon, como trabajadores matutinos en pequeñas empresas de la ciudad.
              somos estudiantes de la Universidas Tecnologica de Leon, en la carrera de Negocios digitales, del turno vespertino..</p>

              <div class="team-social">
                <ul class="list-inline social-list">
                  <li><a href="#" class="fa fa-twitter"></a></li>
                  <li><a href="#" class="fa fa-linkedin"></a></li>
                  <li><a href="#" class="fa fa-facebook"></a></li>
                  <li><a href="#" class="fa fa-google-plus"></a></li>
                </ul> 
              </div>                
            </div>
          </div>
        </div>
      </div> <!-- /.container -->
    </section>
	
	    <!-- INFO -->

    
    
          </div>

          <div class="col-md-3 col-sm-6 col-xs-6">
            <div class="counter animated" data-animate="fadeInUp" data-delay="1500">
              <div class="counter-icon">
                <i class="fa fa-inbox"></i>
              </div>
              <div class="counter-content">
                <span class="value" data-from="0" data-to="1298"></span>
                <small>Mail</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


    <!-- FOOTER CONTACT -->

     <section id="contact" class="dark">
      <header class="title">
        <h2>Contacto <span></span></h2>
        <p>Contactanos, para obtener mas informacion sobre nosotros.</p>
      </header>

  

          <div class="col-md-4 animated" data-animate="fadeInRight">
            <address>
                <span><i class="fa fa-map-marker fa-lg"></i> Centro, Leon gto MX, 37480</span>
                <span><i class="fa fa-phone fa-lg"></i> (123) xxx - xxx</span>
                <span><i class="fa fa-envelope-o fa-lg"></i> <a href="meetme@gmail.com">meetme@gmail.com</a></span>
              
            </address>
          </div>
		  
        </div>
      </div>
    </section>

    <section id="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <p> <i class="fa fa-heart"></i> <a href=""></a></p>
            <p><small>MEETME</small></p>
          </div>
        </div>
      </div>
    </section>

   </div><!-- /.container-fluid -->
    
    <!-- SCRIPT -->
    <script type="text/javascript" src="../resources/js/main.js"></script>
	</body>
</html><?php /**PATH C:\xampp\htdocs\meetme\misitiolaravel\resources\views/index.blade.php ENDPATH**/ ?>