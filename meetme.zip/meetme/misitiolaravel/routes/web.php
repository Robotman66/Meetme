<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\indexController;



Route::get('/bienvenidos',function(){
       return"Route--bienvenidos";
    });

Route::get('/index',function(){
    return "Route --  index";
});






Route::get('/index',[indexController::class,'index']);



Route::get('/index',[indexController::class,'vindex']);



Route::view('/vindex','index');



